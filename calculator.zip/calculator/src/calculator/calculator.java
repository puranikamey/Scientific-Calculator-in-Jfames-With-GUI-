package calculator;

import java.io.*;
import java.lang.Math.*;

public class calculator extends javax.swing.JFrame {
   

    public calculator() {
        
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        num_1 = new javax.swing.JTextField();
        num_2 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        display = new javax.swing.JTextArea();
        Label_1 = new javax.swing.JLabel();
        Label_2 = new javax.swing.JLabel();
        add = new javax.swing.JButton();
        sub = new javax.swing.JButton();
        multiply = new javax.swing.JButton();
        divide = new javax.swing.JButton();
        cos = new javax.swing.JButton();
        sin = new javax.swing.JButton();
        log = new javax.swing.JButton();
        square = new javax.swing.JButton();
        root = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Scientific Calculator");

        display.setColumns(20);
        display.setRows(5);
        jScrollPane1.setViewportView(display);

        Label_1.setText("Number:");

        Label_2.setText("Number: ");

        add.setText("ADD");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        sub.setText("SUBSTRACT");
        sub.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subActionPerformed(evt);
            }
        });

        multiply.setText("MULTIPLY");
        multiply.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                multiplyActionPerformed(evt);
            }
        });

        divide.setText("DIVIDE");
        divide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                divideActionPerformed(evt);
            }
        });

        cos.setText("COS");
        cos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cosActionPerformed(evt);
            }
        });

        sin.setText("SINE");
        sin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sinActionPerformed(evt);
            }
        });

        log.setText("LOG");
        log.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logActionPerformed(evt);
            }
        });

        square.setText("SQUARE");
        square.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                squareActionPerformed(evt);
            }
        });

        root.setText("ROOT");
        root.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rootActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(Label_1)
                .addGap(18, 18, 18)
                .addComponent(num_1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addComponent(Label_2)
                .addGap(18, 18, 18)
                .addComponent(num_2, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(108, 108, 108))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(add, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(sub, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
                            .addComponent(multiply, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(41, 41, 41)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cos, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(divide, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sin, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(log, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(square, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                            .addComponent(root, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(num_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(num_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Label_1)
                    .addComponent(Label_2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(add)
                    .addComponent(divide)
                    .addComponent(log))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sub)
                    .addComponent(cos)
                    .addComponent(square))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(multiply)
                    .addComponent(sin)
                    .addComponent(root))
                .addContainerGap(47, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
         try {
           double x, y,z;

            x = Double.parseDouble(num_1.getText());
            y = Double.parseDouble(num_2.getText());
            z= x+y;
            display.append(" The sum of the two numbers is :: " + z +  "\n" );
            
            
        } catch (Exception e) {
            display.append("please enter the valid numbers");
        }
    }//GEN-LAST:event_addActionPerformed

    private void subActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subActionPerformed
         try {
           double x, y,z;

            x = Double.parseDouble(num_1.getText());
            y = Double.parseDouble(num_2.getText());
            z= x-y;
            display.append(" The substraction  of the two numbers is :: " + z +  "\n" );
            
            
        } catch (Exception e) {
            display.append("please enter the valid numbers");
        }
    }//GEN-LAST:event_subActionPerformed

    private void multiplyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_multiplyActionPerformed
       try {
           double x, y,z;

            x = Double.parseDouble(num_1.getText());
            y = Double.parseDouble(num_2.getText());
            z= x*y;
            display.append(" The Multliplication of the two numbers is :: " + z +  "\n" );
            
            
        } catch (Exception e) {
            display.append("please enter the valid numbers");
        }
    }//GEN-LAST:event_multiplyActionPerformed

    private void divideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_divideActionPerformed
         try {
           double x, y,z;

            x = Double.parseDouble(num_1.getText());
            y = Double.parseDouble(num_2.getText());
            z= x/y;
            display.append(" The Division  of the two numbers is :: " + z +  "\n" );
            
            
        } catch (Exception e) {
            display.append("please enter the valid numbers");
        }
    }//GEN-LAST:event_divideActionPerformed

    private void cosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cosActionPerformed
        try {
           double x, y,z,p,q,a;

            x = Double.parseDouble(num_1.getText());
            y = Double.parseDouble(num_2.getText());
            p = Math.toRadians(x);
            q = Math.toRadians(y);
            z= Math.cos(p);
            a=Math.cos(q);
            display.append(" The Cosine of the first  numbers is :: " + z + "\n" );
            display.append(" The Cosine of the second  numbers is :: " + a + "\n" );
            
        } catch (Exception e) {
            display.append("please enter the valid numbers");
        }
    }//GEN-LAST:event_cosActionPerformed

    private void sinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sinActionPerformed
        try {
           double x, y,z,p,q,a;

            x = Double.parseDouble(num_1.getText());
            y = Double.parseDouble(num_2.getText());
            p = Math.toRadians(x);
            q = Math.toRadians(y);
            z= Math.sin(p);
            a=Math.sin(q);
            display.append(" The Sin of the first  numbers is :: " + z + "\n" );
            display.append(" The Sin of the second  numbers is :: " + a + "\n" );
            
        } catch (Exception e) {
            display.append("please enter the valid numbers");
        }
    }//GEN-LAST:event_sinActionPerformed

    private void logActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logActionPerformed
        try {
           double x, y,z,a;

            x = Double.parseDouble(num_1.getText());
            y = Double.parseDouble(num_2.getText());
            
            z= Math.log10(x);
            a=Math.log10(y);
            display.append(" The Log  of the first  numbers is :: " + z + "\n" );
            display.append(" The log of the second  numbers is :: " + a + "\n" );
            
        } catch (Exception e) {
            display.append("please enter the valid numbers\n");
        }
    }//GEN-LAST:event_logActionPerformed

    private void squareActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_squareActionPerformed
       try {
           double x, y,z,a;

            x = Double.parseDouble(num_1.getText());
            y = Double.parseDouble(num_2.getText());
            z= x*x;
            a=y*y;
            display.append(" The Square of the first numbers is :: " + z +  "\n" );
            display.append(" The Square of the second numbers is :: " + a +  "\n" );
            
        } catch (Exception e) {
            display.append("please enter the valid numbers");
        }
    }//GEN-LAST:event_squareActionPerformed

    private void rootActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rootActionPerformed
         try {
           double x, y,z,a;

            x = Double.parseDouble(num_1.getText());
            y = Double.parseDouble(num_2.getText());
            
            z= Math.sqrt(x);
            a=Math.sqrt(y);
            display.append(" The Square Root  of the first  numbers is :: " + z + "\n" );
            display.append(" The Square Root of the second  numbers is :: " + a + "\n" );
            
        } catch (Exception e) {
            display.append("please enter the valid numbers");
        }
    }//GEN-LAST:event_rootActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new calculator().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Label_1;
    private javax.swing.JLabel Label_2;
    private javax.swing.JButton add;
    private javax.swing.JButton cos;
    private javax.swing.JTextArea display;
    private javax.swing.JButton divide;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton log;
    private javax.swing.JButton multiply;
    private javax.swing.JTextField num_1;
    private javax.swing.JTextField num_2;
    private javax.swing.JButton root;
    private javax.swing.JButton sin;
    private javax.swing.JButton square;
    private javax.swing.JButton sub;
    // End of variables declaration//GEN-END:variables
}
